package com.example.cs125final;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.webianks.library.scroll_choice.ScrollChoice;

import java.util.ArrayList;
import java.util.List;

public class CustomerMenu extends AppCompatActivity {

    List<String> data = new ArrayList<>();
    TextView textView;
    ScrollChoice scrollChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_menu);
        iniViews();
        loadMenu();
        scrollChoice.addItems(data,0); //the default selected is item at index 0
        scrollChoice.setOnItemSelectedListener(new ScrollChoice.OnItemSelectedListener() {
            @Override
            public void onItemSelected(ScrollChoice scrollChoice, int position, String menu) {
                textView.setText("Choice " + menu); //menu is the input string
            }
        });
    }

    private void loadMenu() {
        data.add("Mushroom Swiss Burger");
        data.add("Impossible Burger");
        data.add("Beef Kabob");
        data.add("Grilled Salmon");
        data.add("10oz Sirloin Steak");
        data.add("12oz Ribeye Steak");
        data.add("Steak Tenderloin");
        data.add("Grilled NY Strip Steak");
    }

    private void iniViews() {
        textView = (TextView) findViewById(R.id.txt_result);
        scrollChoice = (ScrollChoice)findViewById(R.id.scroll_choice);
    }
}
