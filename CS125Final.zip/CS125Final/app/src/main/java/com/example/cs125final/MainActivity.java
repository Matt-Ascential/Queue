package com.example.cs125final;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();

        defineButtons();
    }
    public void defineButtons() {
        findViewById(R.id.Customer).setOnClickListener(buttonClickLister);
        findViewById(R.id.Worker).setOnClickListener(buttonClickLister);
    }

    private View.OnClickListener buttonClickLister = new View.OnClickListener() {
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.Customer:
                    startActivity(new Intent(MainActivity.this, CustomerMenu.class));
                    break;

                case R.id.Worker:
                    startActivity(new Intent(MainActivity.this, workerLogin.class));
                    break;
            }
        }
    };

}